# Contact time-correlation analysis tool in DROPPS package by Yiming Tang @ Fudan
# Updated on Apr 19 2026

from argparse import ArgumentParser
import numpy as np
from tqdm import tqdm

from dropps.fileio.filename_control import validate_extension
from dropps.fileio.xpm_reader import write_xpm
from dropps.fileio.xvg_reader import write_xvg

from MDAnalysis.transformations import wrap
from MDAnalysis.lib.nsgrid import FastNS

from dropps.share.trajectory import trajectory_class
from dropps.analysis.contact import compute_residue_contact_maps_fixed

import warnings
from Bio import BiopythonDeprecationWarning
warnings.filterwarnings("ignore", category=BiopythonDeprecationWarning)

prog = "lifetime"
desc = """This program calculates residue-pair time correlation functions and decay times."""


def remove_near_diagonal_nd(arr, cutoff):
    if cutoff < 0:
        return arr
    n = arr.shape[-1]
    i, j = np.ogrid[:n, :n]
    mask = np.abs(i - j) <= cutoff
    arr[..., mask] = 0
    return arr


def write_matrix(filename_raw, matrix, output_type):
    filename = validate_extension(filename_raw, output_type)
    if output_type == "dat":
        np.savetxt(filename, matrix, fmt="%.6f", delimiter="\t")
    elif output_type == "xlsx":
        from pandas import DataFrame
        DataFrame(matrix).to_excel(filename, index=False, header=False)
    elif output_type == "xpm":
        write_xpm(matrix, filename)


def _compute_tcf_fft(series, max_lag_frames):
    """
    series: (T, I, J), values in [0, 1].
    returns:
      corr: (L, I, J), with L = max_lag_frames + 1
      valid_mask: (I, J), True where C(0) > 0
    """
    n_frames, n_i, n_j = series.shape
    x = series.reshape(n_frames, -1).astype(np.float64, copy=False)

    # Wiener-Khinchin autocorrelation in O(T log T) per pair, fully vectorized.
    n_fft = 1 << (2 * n_frames - 1).bit_length()
    fx = np.fft.rfft(x, n=n_fft, axis=0)
    acf = np.fft.irfft(fx * np.conjugate(fx), n=n_fft, axis=0)[:n_frames]

    # Unbiased estimator: divide by number of overlapping samples.
    normalizer = np.arange(n_frames, 0, -1, dtype=np.float64)[:, None]
    acf = acf / normalizer

    if max_lag_frames is not None:
        acf = acf[:max_lag_frames + 1]

    c0 = acf[0]
    valid = c0 > 0.0

    corr = np.zeros_like(acf)
    if np.any(valid):
        corr[:, valid] = acf[:, valid] / c0[valid]

    corr = corr.reshape(corr.shape[0], n_i, n_j)
    valid_mask = valid.reshape(n_i, n_j)
    return corr, valid_mask


def _decay_time_from_correlation(corr, dt_ns, fraction):
    """
    corr: (L, I, J), normalized with corr[0] = 1 where valid.
    Returns matrix (I, J) with first-crossing decay times (ns), linearly interpolated.
    NaN means no crossing within sampled lags.
    """
    n_lag, n_i, n_j = corr.shape
    cflat = corr.reshape(n_lag, -1)

    lag_times = np.arange(n_lag, dtype=np.float64) * float(dt_ns)
    decay = np.full(cflat.shape[1], np.nan, dtype=np.float64)

    below = cflat <= fraction
    has_cross = below.any(axis=0)

    if not np.any(has_cross):
        return decay.reshape(n_i, n_j)

    first_idx = np.argmax(below, axis=0)
    cols = np.where(has_cross)[0]
    k = first_idx[cols]

    zero_cross = (k == 0)
    if np.any(zero_cross):
        decay[cols[zero_cross]] = 0.0

    nonzero_cross = ~zero_cross
    if np.any(nonzero_cross):
        cols2 = cols[nonzero_cross]
        k2 = k[nonzero_cross]

        c2 = cflat[k2, cols2]
        c1 = cflat[k2 - 1, cols2]
        t2 = lag_times[k2]
        t1 = lag_times[k2 - 1]

        denom = c2 - c1
        interp = np.empty_like(t2)

        same = np.isclose(denom, 0.0)
        interp[same] = t2[same]
        interp[~same] = t1[~same] + (fraction - c1[~same]) * (t2[~same] - t1[~same]) / denom[~same]

        decay[cols2] = np.clip(interp, t1, t2)

    return decay.reshape(n_i, n_j)


def getargs_lifetime(argv):
    parser = ArgumentParser(prog=prog, description=desc)

    parser.add_argument('-s', '--run-input', type=str, required=True,
                        help="TPR file containing all information for a simulation run.")

    parser.add_argument('-f', '--input', type=str, required=True,
                        help="XTC file which is taken as input trajectory.")

    parser.add_argument('-n', '--index', type=str, required=False,
                        help="Index file containing non-default groups.")

    parser.add_argument('-ref', '--reference-group', type=str,
                        help="Reference group of atoms (x axis).")

    parser.add_argument('-sel', '--selection-group', type=str,
                        help="Selection group of atoms (y axis).")

    parser.add_argument('-cs', '--cutoff-scheme', type=str, choices=["global", "residue"], required=True,
                        help="Scheme for determining inter-residue contacts.")

    parser.add_argument('-c', '--cutoff', type=float, default=0.7,
                        help="Cutoff distance for contact calculation, unit is nanometer.")

    parser.add_argument('-cm', '--cutoff-multiplier', type=float, default=1.2,
                        help="Factor multiplied to sigma value for residue-wise contact cutoff.")

    parser.add_argument('-rd', '--remove-diagonal', type=int, default=2,
                        help="Number of diagonals (i - j <= abs(rd)) to ignore for intra-chain interactions.")

    parser.add_argument('-b', '--start-time', type=int,
                        help="Time (ns) of the first frame to calculate.")

    parser.add_argument('-e', '--end-time', type=int,
                        help="Time (ns) of the last frame to calculate.")

    parser.add_argument('-dt', '--delta-time', type=int,
                        help="Intervals (ns) between two calculated frames.")

    parser.add_argument('-pbc', '--treat-pbc', action='store_true', default=False,
                        help="Treat broken molecule at periodic boundaries.")

    parser.add_argument('-otype', '--output-type', type=str, choices=["dat", "xpm", "xlsx"], default="dat",
                        help="Type of decay-time matrix output files. Choices: dat, xpm, xlsx")

    parser.add_argument('-frac', '--decay-fraction', type=float, default=np.exp(-1.0),
                        help="Target fraction for decay time extraction (default: 1/e).")

    parser.add_argument('-mlf', '--max-lag-frames', type=int,
                        help="Maximum lag (in sampled frames) for correlation calculation. Default uses all lags.")

    # decay time matrix outputs
    parser.add_argument('-odrs', '--output-decay-inter-reference-selection', type=str,
                        help="Output matrix of decay times for inter-chain reference-selection interactions.")
    parser.add_argument('-odrr', '--output-decay-inter-reference-reference', type=str,
                        help="Output matrix of decay times for inter-chain reference-reference interactions.")
    parser.add_argument('-odss', '--output-decay-inter-selection-selection', type=str,
                        help="Output matrix of decay times for inter-chain selection-selection interactions.")
    parser.add_argument('-odr', '--output-decay-intra-reference', type=str,
                        help="Output matrix of decay times for intra-chain reference interactions.")
    parser.add_argument('-ods', '--output-decay-intra-selection', type=str,
                        help="Output matrix of decay times for intra-chain selection interactions.")

    # average correlation outputs
    parser.add_argument('-ocrs', '--output-correlation-mean-inter-reference-selection', type=str,
                        help="Output XVG of mean time correlation function for inter-chain reference-selection interactions.")
    parser.add_argument('-ocrr', '--output-correlation-mean-inter-reference-reference', type=str,
                        help="Output XVG of mean time correlation function for inter-chain reference-reference interactions.")
    parser.add_argument('-ocss', '--output-correlation-mean-inter-selection-selection', type=str,
                        help="Output XVG of mean time correlation function for inter-chain selection-selection interactions.")
    parser.add_argument('-ocr', '--output-correlation-mean-intra-reference', type=str,
                        help="Output XVG of mean time correlation function for intra-chain reference interactions.")
    parser.add_argument('-ocs', '--output-correlation-mean-intra-selection', type=str,
                        help="Output XVG of mean time correlation function for intra-chain selection interactions.")

    # full pairwise correlation outputs
    parser.add_argument('-ofrs', '--output-correlation-full-inter-reference-selection', type=str,
                        help="Output NPZ of full pairwise correlation for inter-chain reference-selection interactions.")
    parser.add_argument('-ofrr', '--output-correlation-full-inter-reference-reference', type=str,
                        help="Output NPZ of full pairwise correlation for inter-chain reference-reference interactions.")
    parser.add_argument('-ofss', '--output-correlation-full-inter-selection-selection', type=str,
                        help="Output NPZ of full pairwise correlation for inter-chain selection-selection interactions.")
    parser.add_argument('-ofr', '--output-correlation-full-intra-reference', type=str,
                        help="Output NPZ of full pairwise correlation for intra-chain reference interactions.")
    parser.add_argument('-ofs', '--output-correlation-full-intra-selection', type=str,
                        help="Output NPZ of full pairwise correlation for intra-chain selection interactions.")

    args = parser.parse_args(argv)
    return args


def lifetime(args):
    try:
        trajectory = trajectory_class(args.run_input, args.index, args.input)
    except Exception as exc:
        print("## An exception occurred when trying to open trajectory file %s." % args.input)
        print(f"## Root cause: {exc}")
        quit()

    trajectory.Universe.trajectory.add_transformations(wrap(trajectory.Universe.atoms))

    start_frame, end_frame, interval_frame = trajectory.time2frame(args.start_time, args.end_time, args.delta_time)

    if args.reference_group is None or args.selection_group is None:
        trajectory.index.print_all()

    if args.reference_group is not None:
        print(f"## Will use group {args.reference_group} as reference group.")
        reference_group, reference_group_name = trajectory.getSelection(f"group {args.reference_group}")
    else:
        reference_group, reference_group_name = trajectory.getSelection_interactive("reference group")

    if args.selection_group is not None:
        print(f"## Will use group {args.selection_group} as selection group.")
        selection_group, selection_group_name = trajectory.getSelection(f"group {args.selection_group}")
    else:
        selection_group, selection_group_name = trajectory.getSelection_interactive("selection group (can be empty)")

    ref_length = len(reference_group.indices)
    sel_length = len(selection_group.indices)
    print(f"## Reference group '{reference_group_name}' has {ref_length} atoms.")
    print(f"## Selection group '{selection_group_name}' has {sel_length} atoms.")

    if ref_length == 0:
        print("ERROR: Reference group has zero atoms.")
        quit()

    has_selection = sel_length > 0
    if not has_selection:
        print("## WARNING: Selection group has zero atoms. Please make sure this is intended.")

    reference_chains = trajectory.index.splitch_indices(reference_group.indices)
    chain_length_list_reference = [len(chain) for chain in reference_chains]
    if len(set(chain_length_list_reference)) != 1:
        print("ERROR: Chains in reference groups are not same in length.")
        quit()
    chain_length_reference = chain_length_list_reference[0]
    print(f"## Processed {len(reference_chains)} chains of length {chain_length_reference} in reference group.")

    if has_selection:
        selection_chains = trajectory.index.splitch_indices(selection_group.indices)
        chain_length_list_selection = [len(chain) for chain in selection_chains]
        if len(set(chain_length_list_selection)) != 1:
            print("ERROR: Chains in selection groups are not same in length.")
            quit()
        chain_length_selection = chain_length_list_selection[0]
        print(f"## Processed {len(selection_chains)} chains of length {chain_length_selection} in selection group.")
    else:
        selection_chains = None

    output_fields = {
        "rs": (
            args.output_decay_inter_reference_selection,
            args.output_correlation_mean_inter_reference_selection,
            args.output_correlation_full_inter_reference_selection,
        ),
        "rr": (
            args.output_decay_inter_reference_reference,
            args.output_correlation_mean_inter_reference_reference,
            args.output_correlation_full_inter_reference_reference,
        ),
        "ss": (
            args.output_decay_inter_selection_selection,
            args.output_correlation_mean_inter_selection_selection,
            args.output_correlation_full_inter_selection_selection,
        ),
        "r": (
            args.output_decay_intra_reference,
            args.output_correlation_mean_intra_reference,
            args.output_correlation_full_intra_reference,
        ),
        "s": (
            args.output_decay_intra_selection,
            args.output_correlation_mean_intra_selection,
            args.output_correlation_full_intra_selection,
        ),
    }

    if not has_selection:
        if any(output_fields["rs"]) or any(output_fields["ss"]) or any(output_fields["s"]):
            print("ERROR: Selection group is empty, but output files for selection-related interactions are specified.")
            quit()

    keys_requested = [k for k, fields in output_fields.items() if any(fields)]
    if len(keys_requested) == 0:
        print("## ERROR: No output files are specified, exiting.")
        quit()

    if not (0.0 < args.decay_fraction < 1.0):
        print("ERROR: Decay fraction should be between 0 and 1.")
        quit()

    if args.cutoff_scheme == "global":
        print(f"## Will use a global cutoff of {args.cutoff} nm.")
        cutoff = args.cutoff * 10.0
        cutoff_vector = None
    elif args.cutoff_scheme == "residue":
        print(f"## Will use residue-responsive cutoff with sigma multiplier {args.cutoff_multiplier}.")
        cutoff_vector = np.array([args.cutoff_multiplier * sigma * 10.0 for sigma in trajectory.sigmas])
        cutoff = cutoff_vector.max()
    else:
        print(f"ERROR: Unknown cutoff scheme {args.cutoff_scheme}.")
        quit()

    frame_slice = trajectory.Universe.trajectory[start_frame:end_frame:interval_frame]
    n_frames = len(frame_slice)
    if n_frames == 0:
        print("ERROR: No frames selected for analysis.")
        quit()

    dt_ps = trajectory.Universe.trajectory.dt * interval_frame
    dt_ns = dt_ps / 1000.0
    if dt_ns <= 0:
        print("ERROR: Invalid trajectory time step. Please verify the input trajectory.")
        quit()

    if args.max_lag_frames is None:
        max_lag_frames = n_frames - 1
    else:
        if args.max_lag_frames < 1:
            print("ERROR: max-lag-frames should be >= 1.")
            quit()
        max_lag_frames = min(args.max_lag_frames, n_frames - 1)

    print(f"## Correlation will use {dt_ns:.6f} ns per sampled frame.")
    print(f"## Decay threshold fraction is {args.decay_fraction:.6f}.")
    print(f"## Maximum lag is {max_lag_frames} frames ({max_lag_frames * dt_ns:.6f} ns).")

    if has_selection:
        search_atom_indices = np.sort(np.asarray(list(set(reference_group.indices).union(set(selection_group.indices))), dtype=np.int64))
    else:
        search_atom_indices = np.sort(np.asarray(reference_group.indices, dtype=np.int64))
    search_atoms = trajectory.Universe.atoms[search_atom_indices]

    n_ref = len(reference_chains)
    l_ref = len(reference_chains[0])

    if has_selection:
        n_sel = len(selection_chains)
        l_sel = len(selection_chains[0])

    pair_shapes = {
        "r": (l_ref, l_ref),
        "rr": (l_ref, l_ref),
    }
    if has_selection:
        pair_shapes.update({
            "s": (l_sel, l_sel),
            "ss": (l_sel, l_sel),
            "rs": (l_ref, l_sel),
        })

    series_data = {
        key: np.zeros((n_frames, pair_shapes[key][0], pair_shapes[key][1]), dtype=np.float32)
        for key in keys_requested
    }

    print("## Building per-pair contact time series for correlation analysis.")
    for frame_idx, ts in enumerate(tqdm(frame_slice)):
        pos = search_atoms.positions
        box = ts.dimensions
        ns = FastNS(cutoff, pos, box=box, pbc=args.treat_pbc)

        result = ns.self_search()
        pairs = result.get_pairs()
        pairs_atomid = search_atom_indices[pairs]

        if args.cutoff_scheme == "residue":
            cutoffs = cutoff_vector[pairs_atomid].mean(axis=1)
            pair_distances = result.get_pair_distances()
            mask = pair_distances <= cutoffs
            pairs_atomid = pairs_atomid[mask]

        maps = compute_residue_contact_maps_fixed(
            pairs_atomid,
            reference_chains,
            selection_chains if has_selection else None,
            undirected=True,
            unique_pairs=False,
            drop_self_pairs=True,
            dtype=np.int64,
        )

        if "r" in series_data:
            ref_intra = (maps["ref_intra"] > 0).astype(np.float32)
            ref_intra = remove_near_diagonal_nd(ref_intra, args.remove_diagonal)
            series_data["r"][frame_idx] = ref_intra.mean(axis=0, dtype=np.float32)

        if "rr" in series_data:
            ref_ref = (maps["ref_ref_inter"] > 0).astype(np.float32)
            denom = float(n_ref * (n_ref - 1))
            if denom > 0:
                series_data["rr"][frame_idx] = ref_ref.sum(axis=(0, 1), dtype=np.float32) / denom
            else:
                series_data["rr"][frame_idx] = 0.0

        if has_selection:
            if "s" in series_data:
                sel_intra = (maps["sel_intra"] > 0).astype(np.float32)
                sel_intra = remove_near_diagonal_nd(sel_intra, args.remove_diagonal)
                series_data["s"][frame_idx] = sel_intra.mean(axis=0, dtype=np.float32)

            if "ss" in series_data:
                sel_sel = (maps["sel_sel_inter"] > 0).astype(np.float32)
                denom = float(n_sel * (n_sel - 1))
                if denom > 0:
                    series_data["ss"][frame_idx] = sel_sel.sum(axis=(0, 1), dtype=np.float32) / denom
                else:
                    series_data["ss"][frame_idx] = 0.0

            if "rs" in series_data:
                ref_sel = (maps["ref_sel_inter"] > 0).astype(np.float32)
                denom = float(n_ref * n_sel)
                series_data["rs"][frame_idx] = ref_sel.sum(axis=(0, 1), dtype=np.float32) / denom

    print("## Time series built. Calculating correlation functions and decay times.")

    for key in keys_requested:
        corr, valid_mask = _compute_tcf_fft(series_data[key], max_lag_frames=max_lag_frames)
        decay = _decay_time_from_correlation(corr, dt_ns=dt_ns, fraction=args.decay_fraction)
        fields = output_fields[key]

        decay_file, mean_corr_file, full_corr_file = fields

        if decay_file is not None:
            write_matrix(decay_file, decay, args.output_type)

        lag_times = np.arange(corr.shape[0], dtype=np.float64) * dt_ns

        if mean_corr_file is not None:
            filename = validate_extension(mean_corr_file, "xvg")
            if np.any(valid_mask):
                mean_corr = corr[:, valid_mask].mean(axis=1)
            else:
                mean_corr = np.zeros(corr.shape[0], dtype=np.float64)
            legend = f"corr-{key}"
            write_xvg(
                filename,
                lag_times,
                mean_corr,
                title=f"Mean time correlation ({legend})",
                xlabel="Lag time (ns)",
                ylabel="C(t)",
                legends=[legend],
            )

        if full_corr_file is not None:
            filename = validate_extension(full_corr_file, "npz")
            np.savez_compressed(
                filename,
                lag_time_ns=lag_times,
                correlation=corr,
                valid_mask=valid_mask,
            )

    print("## Correlation analysis completed. Requested outputs have been written.")


from dropps.share.command_class import single_command
lifetime_commands = single_command("lifetime", getargs_lifetime, lifetime, desc)
