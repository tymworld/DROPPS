from pathlib import Path

from setuptools import find_packages, setup


repository = Path(__file__).parent

setup(
    name="dropps",
    version="0.4.1",
    description="Distributed Rapid Operation Platform for Phase-separation Simulations",
    long_description=(repository / "README.md").read_text(encoding="utf-8"),
    long_description_content_type="text/markdown",
    author="Yiming Tang",
    author_email="ymtang@fudan.edu.cn",
    license="LicenseRef-Proprietary",
    license_files=("LICENSE.md",),
    python_requires=">=3.10",
    packages=find_packages(exclude=("dropps.backups", "dropps.backups.*")),
    package_data={
        "dropps": ["share/forcefields/*.ff", "share/templates/*.mdp"],
    },
    include_package_data=False,
    install_requires=[
        "numpy==1.26.4",
        "openmm==8.1.*",
        "MDAnalysis>=2.7.0",
        "tqdm>=4.67",
        "bio>=1.6.2",
    ],
    entry_points={"console_scripts": ["dps=dropps.dps:main"]},
)
